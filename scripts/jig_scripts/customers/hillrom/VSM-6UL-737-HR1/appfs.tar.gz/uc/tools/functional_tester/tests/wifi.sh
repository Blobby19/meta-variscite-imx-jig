#!/usr/bin/env sh

iw dev wlan0 scan | egrep "SSID: $1\b"

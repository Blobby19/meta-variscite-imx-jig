#!/usr/bin/env sh

# should be 1 or 2
USBPORT=$1
MNTPOINT="/tmp/usb$USBPORT"
FILENAME="/tmp/usb$USBPORT/usb_test"

exit_func()
{
	rm $FILENAME &> /dev/null
	umount $MNTPOINT &> /dev/null
	rm -rf $MNTPOINT &> /dev/null
	/opt/local/hrapps/uc/bin/uc_usb_power.sh -12d
	exit $1
}


# enable usb power and delay for usb enumeration
if [ ! -d /dev/sda1 ] || [ ! -d /dev/sdb1 ]; then
	/opt/local/hrapps/uc/bin/uc_usb_power.sh -12e
	sleep 5
fi

for sd in /dev/sd?; do
	DEV=$( udevadm info -q path -n $sd | grep "usb$USBPORT" )
	if (( ! "$?" )); then
		break
	fi
done

if [ -z "$DEV" ]; then
	exit_func 1
fi

echo "DEV=$DEV"

DEV="/dev/${DEV: -3}1"
echo "Mounting $DEV @ $MNTPOINT"
mkdir -p $MNTPOINT
mount $DEV $MNTPOINT
if (( "$?" )); then
	exit_func 2
fi

# create random data of undetermined length
# because busybox head can't count characters
TESTDATA=$( cat /dev/urandom | head )

echo "Reading from $FILENAME"
echo -n "$TESTDATA" > $FILENAME
echo "Writing from $FILENAME"
READDATA=$( cat $FILENAME )

if [ "$TESTDATA" != "$READDATA" ]; then
	exit_func 3
fi

echo "Data written to file matched data read from file"
exit_func 0


#!/usr/bin/env sh

DEVICE=$1 # should be "grs7" or "grs10h"
USBPORT=$2 # grs10 needs to be 1-4, unused on grs7

MNTPOINT="/tmp/usb${USBPORT}"
FILENAME="/tmp/usb${USBPORT}/usb_test"

if [[ "$DEVICE" == "grs10h" ]]; then
	PORT_GREP_STRING="usb2/2-1/2-1.${USBPORT}"
elif [[ "$DEVICE" == "grs7" ]]; then
	PORT_GREP_STRING="usb1/1-1/1-1:1.0"
fi

DEV_NODE=""

exit_func()
{
	rm $FILENAME &> /dev/null
	umount $MNTPOINT &> /dev/null
	rm -rf $MNTPOINT &> /dev/null
	exit $1
}

for sd in /dev/sd?; do
	udevadm info -q path -n $sd | grep "${PORT_GREP_STRING}"
	if (( ! "$?" )); then
        DEV_NODE=${sd}1
		break
	fi
done

# mass storage device not found on port
if [ -z "$DEV_NODE" ]; then
	exit_func 1
fi

echo "Mounting $DEV_NODE @ $MNTPOINT"
mkdir -p $MNTPOINT
echo "mount $DEV_NODE $MNTPOINT"
mount $DEV_NODE $MNTPOINT
if (( "$?" )); then
	exit_func 2
fi

TESTDATA=$( dd if=/dev/urandom bs=512 count=1 )

echo "Reading from $FILENAME"
echo -n "$TESTDATA" > $FILENAME
echo "Writing from $FILENAME"
READDATA=$( cat $FILENAME )

if [ "$TESTDATA" != "$READDATA" ]; then
	exit_func 3
fi

echo "Data written to file matched data read from file"
exit_func 0

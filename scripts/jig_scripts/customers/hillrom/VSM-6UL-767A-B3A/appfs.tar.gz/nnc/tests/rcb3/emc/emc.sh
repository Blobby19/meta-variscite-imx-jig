#!/bin/sh
#**********************************************************************
# Copyright (C) 2017 Hill-Rom - All Rights Reserved.
#
# This file embodies materials and concepts which are confidential
# and proprietary to Hill-Rom, and is made available solely pursuant
# to the terms of a written agreement with Hill-Rom.
#**********************************************************************
 
# EMC Temp Testing

pingTest()
{
    while true; do
        ping -w 1 -q $1 > /dev/null
        if [ $? == 1 ]; then
            echo "Ping to $1 [$2] Failed."
	    sleep 10
        fi
    done
}

relayTest()
{
    echo 111 > /sys/class/gpio/export
    echo out > /sys/class/gpio/gpio111/direction
    echo 107 > /sys/class/gpio/export
    echo out > /sys/class/gpio/gpio107/direction

    while true; do
        echo 0 > /sys/class/gpio/gpio111/value
        echo 0 > /sys/class/gpio/gpio107/value
        sleep 1
        echo 1 > /sys/class/gpio/gpio111/value
        echo 1 > /sys/class/gpio/gpio107/value
        sleep 1
    done
}

doAll()
{
    # configure DUTs Static IP Address
    ifconfig eth0 192.168.0.1
    # ping GRS10 Port Static IP Address
    pingTest 192.168.0.2 GRS10 &
    # ping POE Port Static IP Address
    pingTest 192.168.0.3 "POE Port" &
    # downstream power
    echo 113 > /sys/class/gpio/export
    echo 114 > /sys/class/gpio/export
    echo 133 > /sys/class/gpio/export
    echo out > /sys/class/gpio/gpio114/direction
    echo out > /sys/class/gpio/gpio113/direction
    echo out > /sys/class/gpio/gpio133/direction
    echo 0 > /sys/class/gpio/gpio113/value
    echo 1 > /sys/class/gpio/gpio114/value
    echo 1 > /sys/class/gpio/gpio133/value
    echo 1 > /sys/class/gpio/gpio113/value
    # kill nnc app
    /opt/local/hrapps/etc/init/nnc-init stop
    # continously play tone in background
    /opt/local/hrapps/nnc/bin/audio-setup.sh
    /opt/local/hrapps/nnc/bin/functional_tester -f /opt/local/hrapps/nnc/tests/rcb3/emc/setup_audio_routing.json
    { while true; do aplay /opt/local/hrapps/nnc/tests/common/Tone_1kHz_Amplitude1_16.wav 2> /dev/null; done } &
    relayTest &
    /opt/local/hrapps/nnc/bin/functional_tester -q -r -f /opt/local/hrapps/nnc/tests/rcb3/emc/emc.json  
}
 
doAll &
